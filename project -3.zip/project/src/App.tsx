import { useState } from 'react';
import {
  Activity,
  Database,
  Globe,
  Shield,
  Settings,
  Plus,
  Play,
  Pause,
  Trash2,
  RefreshCw,
  CheckCircle,
  XCircle,
  Clock,
  Zap,
  AlertTriangle,
  Server,
  Eye,
  ChevronRight,
  TrendingUp,
  BarChart3
} from 'lucide-react';

interface Proxy {
  id: string;
  ip: string;
  port: number;
  country: string;
  status: 'active' | 'cooldown' | 'failed';
  successRate: number;
  lastUsed: string;
  responseTime: number;
}

interface ScrapeJob {
  id: string;
  name: string;
  url: string;
  status: 'running' | 'completed' | 'failed' | 'queued' | 'paused';
  progress: number;
  pagesScraped: number;
  totalPages: number;
  startTime: string;
  proxiesUsed: number;
  captchasSolved: number;
  errors: number;
}

interface ScrapeResult {
  id: string;
  jobName: string;
  url: string;
  data: Record<string, string>;
  scrapedAt: string;
  status: 'success' | 'failed';
}

type View = 'dashboard' | 'jobs' | 'proxies' | 'results' | 'settings';

function App() {
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [showNewJobModal, setShowNewJobModal] = useState(false);
  const [activeJobs, setActiveJobs] = useState<ScrapeJob[]>([
    {
      id: '1',
      name: 'E-commerce Price Monitor',
      url: 'https://example-store.com/products',
      status: 'running',
      progress: 67,
      pagesScraped: 3347,
      totalPages: 5000,
      startTime: '2026-05-28T10:30:00Z',
      proxiesUsed: 23,
      captchasSolved: 12,
      errors: 8
    },
    {
      id: '2',
      name: 'News Aggregator',
      url: 'https://news-source.com/articles',
      status: 'completed',
      progress: 100,
      pagesScraped: 1200,
      totalPages: 1200,
      startTime: '2026-05-28T08:00:00Z',
      proxiesUsed: 15,
      captchasSolved: 5,
      errors: 2
    },
    {
      id: '3',
      name: 'Real Estate Listings',
      url: 'https://property-site.com/listings',
      status: 'paused',
      progress: 34,
      pagesScraped: 850,
      totalPages: 2500,
      startTime: '2026-05-28T09:15:00Z',
      proxiesUsed: 18,
      captchasSolved: 28,
      errors: 15
    }
  ]);

  const [proxyPool, setProxyPool] = useState<Proxy[]>([
    { id: '1', ip: '192.168.1.100', port: 8080, country: 'US', status: 'active', successRate: 98.5, lastUsed: '2 min ago', responseTime: 120 },
    { id: '2', ip: '10.0.0.50', port: 3128, country: 'DE', status: 'active', successRate: 96.2, lastUsed: '5 min ago', responseTime: 145 },
    { id: '3', ip: '172.16.0.25', port: 8888, country: 'UK', status: 'cooldown', successRate: 89.1, lastUsed: '1 min ago', responseTime: 230 },
    { id: '4', ip: '203.0.113.42', port: 8080, country: 'JP', status: 'active', successRate: 97.8, lastUsed: '8 min ago', responseTime: 185 },
    { id: '5', ip: '198.51.100.15', port: 8080, country: 'CA', status: 'failed', successRate: 45.2, lastUsed: '12 min ago', responseTime: 890 },
    { id: '6', ip: '192.0.2.200', port: 3128, country: 'AU', status: 'active', successRate: 94.7, lastUsed: '3 min ago', responseTime: 156 },
  ]);

  const [results] = useState<ScrapeResult[]>([
    {
      id: '1',
      jobName: 'E-commerce Price Monitor',
      url: 'https://example-store.com/products/123',
      data: { title: 'Wireless Headphones Pro', price: '$149.99', rating: '4.8', stock: 'In Stock' },
      scrapedAt: '2026-05-28T10:35:00Z',
      status: 'success'
    },
    {
      id: '2',
      jobName: 'E-commerce Price Monitor',
      url: 'https://example-store.com/products/456',
      data: { title: 'Smart Watch Series X', price: '$299.99', rating: '4.6', stock: 'Limited' },
      scrapedAt: '2026-05-28T10:32:00Z',
      status: 'success'
    }
  ]);

  const toggleJobStatus = (jobId: string) => {
    setActiveJobs(jobs => jobs.map(job => {
      if (job.id === jobId) {
        return { ...job, status: job.status === 'running' ? 'paused' : 'running' };
      }
      return job;
    }));
  };

  const deleteJob = (jobId: string) => {
    setActiveJobs(jobs => jobs.filter(job => job.id !== jobId));
  };

  const rotateProxy = (proxyId: string) => {
    setProxyPool(proxies => proxies.map(proxy => {
      if (proxy.id === proxyId) {
        return { ...proxy, status: 'cooldown', lastUsed: 'Now' };
      }
      return proxy;
    }));
  };

  const removeProxy = (proxyId: string) => {
    setProxyPool(proxies => proxies.filter(proxy => proxy.id !== proxyId));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running':
      case 'active':
        return 'text-emerald-400 bg-emerald-400/10';
      case 'completed':
      case 'success':
        return 'text-blue-400 bg-blue-400/10';
      case 'paused':
      case 'cooldown':
        return 'text-amber-400 bg-amber-400/10';
      case 'failed':
        return 'text-red-400 bg-red-400/10';
      case 'queued':
        return 'text-slate-400 bg-slate-400/10';
      default:
        return 'text-slate-400 bg-slate-400/10';
    }
  };

  const stats = {
    totalRequests: 158427,
    successRate: 96.8,
    activeProxies: proxyPool.filter(p => p.status === 'active').length,
    totalProxies: proxyPool.length,
    captchasSolved: 45,
    jobsCompleted: 12,
    jobsActive: activeJobs.filter(j => j.status === 'running').length
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col">
        <div className="p-6 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
              <Globe className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-semibold text-white">ScraperPro</h1>
              <p className="text-xs text-slate-500">Enterprise Edition</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          {[
            { id: 'dashboard', icon: BarChart3, label: 'Dashboard' },
            { id: 'jobs', icon: Activity, label: 'Scrape Jobs' },
            { id: 'proxies', icon: Shield, label: 'Proxy Pool' },
            { id: 'results', icon: Database, label: 'Extracted Data' },
            { id: 'settings', icon: Settings, label: 'Settings' },
          ].map(item => (
            <button
              key={item.id}
              onClick={() => setCurrentView(item.id as View)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                currentView === item.id
                  ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <item.icon className="w-5 h-5" />
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-800">
          <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 rounded-lg p-4 border border-cyan-500/20">
            <div className="flex items-center gap-2 mb-2">
              <Zap className="w-4 h-4 text-cyan-400" />
              <span className="text-sm font-medium text-cyan-400">Pro Plan Active</span>
            </div>
            <p className="text-xs text-slate-400">Unlimited requests & priority support</p>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Top Header */}
        <header className="bg-slate-900/50 backdrop-blur border-b border-slate-800 px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-white">
                {currentView === 'dashboard' && 'Dashboard Overview'}
                {currentView === 'jobs' && 'Scrape Jobs'}
                {currentView === 'proxies' && 'Proxy Pool Management'}
                {currentView === 'results' && 'Extracted Data'}
                {currentView === 'settings' && 'Settings'}
              </h2>
              <p className="text-sm text-slate-500 mt-1">
                {currentView === 'dashboard' && 'Monitor your scraping operations in real-time'}
                {currentView === 'jobs' && 'Create and manage your web scraping jobs'}
                {currentView === 'proxies' && 'Manage your proxy rotation pool'}
                {currentView === 'results' && 'View and export extracted data'}
                {currentView === 'settings' && 'Configure your scraper settings'}
              </p>
            </div>
            <div className="flex items-center gap-3">
              {currentView === 'jobs' && (
                <button
                  onClick={() => setShowNewJobModal(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-cyan-500 hover:bg-cyan-600 text-white rounded-lg font-medium transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  New Job
                </button>
              )}
              <div className="flex items-center gap-2 px-4 py-2 bg-slate-800 rounded-lg">
                <Server className="w-4 h-4 text-slate-400" />
                <span className="text-sm text-slate-300">{stats.activeProxies}/{stats.totalProxies} Active</span>
              </div>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-auto p-8">
          {currentView === 'dashboard' && (
            <div className="space-y-6">
              {/* Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="bg-slate-900 rounded-xl p-6 border border-slate-800">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-slate-400 text-sm">Total Requests</span>
                    <TrendingUp className="w-5 h-5 text-cyan-400" />
                  </div>
                  <p className="text-3xl font-bold text-white">{stats.totalRequests.toLocaleString()}</p>
                  <p className="text-sm text-emerald-400 mt-2">+12.5% from last week</p>
                </div>

                <div className="bg-slate-900 rounded-xl p-6 border border-slate-800">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-slate-400 text-sm">Success Rate</span>
                    <CheckCircle className="w-5 h-5 text-emerald-400" />
                  </div>
                  <p className="text-3xl font-bold text-white">{stats.successRate}%</p>
                  <p className="text-sm text-slate-500 mt-2">Last 24 hours</p>
                </div>

                <div className="bg-slate-900 rounded-xl p-6 border border-slate-800">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-slate-400 text-sm">Active Jobs</span>
                    <Activity className="w-5 h-5 text-blue-400" />
                  </div>
                  <p className="text-3xl font-bold text-white">{stats.jobsActive}</p>
                  <p className="text-sm text-slate-500 mt-2">{stats.jobsCompleted} completed today</p>
                </div>

                <div className="bg-slate-900 rounded-xl p-6 border border-slate-800">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-slate-400 text-sm">CAPTCHAs Solved</span>
                    <Shield className="w-5 h-5 text-amber-400" />
                  </div>
                  <p className="text-3xl font-bold text-white">{stats.captchasSolved}</p>
                  <p className="text-sm text-slate-500 mt-2">Auto-solved via API</p>
                </div>
              </div>

              {/* Live Jobs & Proxy Status */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Active Jobs */}
                <div className="bg-slate-900 rounded-xl border border-slate-800">
                  <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
                    <h3 className="font-semibold text-white">Active Jobs</h3>
                    <button onClick={() => setCurrentView('jobs')} className="text-cyan-400 hover:text-cyan-300 text-sm flex items-center gap-1">
                      View All <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="divide-y divide-slate-800">
                    {activeJobs.filter(j => j.status === 'running' || j.status === 'paused').slice(0, 3).map(job => (
                      <div key={job.id} className="px-6 py-4">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium text-white">{job.name}</span>
                          <span className={`px-2 py-1 rounded text-xs font-medium ${getStatusColor(job.status)}`}>
                            {job.status}
                          </span>
                        </div>
                        <div className="w-full bg-slate-700 rounded-full h-2 mb-2">
                          <div
                            className="bg-gradient-to-r from-cyan-500 to-blue-500 h-2 rounded-full transition-all"
                            style={{ width: `${job.progress}%` }}
                          />
                        </div>
                        <div className="flex items-center justify-between text-sm text-slate-400">
                          <span>{job.pagesScraped.toLocaleString()} / {job.totalPages.toLocaleString()} pages</span>
                          <span>{job.progress}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Proxy Health */}
                <div className="bg-slate-900 rounded-xl border border-slate-800">
                  <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
                    <h3 className="font-semibold text-white">Proxy Health</h3>
                    <button onClick={() => setCurrentView('proxies')} className="text-cyan-400 hover:text-cyan-300 text-sm flex items-center gap-1">
                      Manage <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-6">
                      <div className="text-center">
                        <p className="text-3xl font-bold text-emerald-400">{stats.activeProxies}</p>
                        <p className="text-sm text-slate-400">Active</p>
                      </div>
                      <div className="text-center">
                        <p className="text-3xl font-bold text-amber-400">{proxyPool.filter(p => p.status === 'cooldown').length}</p>
                        <p className="text-sm text-slate-400">Cooldown</p>
                      </div>
                      <div className="text-center">
                        <p className="text-3xl font-bold text-red-400">{proxyPool.filter(p => p.status === 'failed').length}</p>
                        <p className="text-sm text-slate-400">Failed</p>
                      </div>
                    </div>
                    <div className="space-y-3">
                      {proxyPool.slice(0, 3).map(proxy => (
                        <div key={proxy.id} className="flex items-center justify-between py-2 px-3 bg-slate-800/50 rounded-lg">
                          <div className="flex items-center gap-3">
                            <span className={`w-2 h-2 rounded-full ${proxy.status === 'active' ? 'bg-emerald-400' : proxy.status === 'cooldown' ? 'bg-amber-400' : 'bg-red-400'}`} />
                            <span className="text-sm text-slate-300">{proxy.ip}:{proxy.port}</span>
                            <span className="text-xs text-slate-500">{proxy.country}</span>
                          </div>
                          <span className="text-sm text-slate-400">{proxy.successRate}%</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {currentView === 'jobs' && (
            <div className="space-y-6">
              <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-slate-800/50">
                      <tr>
                        <th className="text-left px-6 py-4 text-sm font-medium text-slate-400">Job Name</th>
                        <th className="text-left px-6 py-4 text-sm font-medium text-slate-400">Target URL</th>
                        <th className="text-left px-6 py-4 text-sm font-medium text-slate-400">Status</th>
                        <th className="text-left px-6 py-4 text-sm font-medium text-slate-400">Progress</th>
                        <th className="text-left px-6 py-4 text-sm font-medium text-slate-400">Stats</th>
                        <th className="text-right px-6 py-4 text-sm font-medium text-slate-400">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {activeJobs.map(job => (
                        <tr key={job.id} className="hover:bg-slate-800/30 transition-colors">
                          <td className="px-6 py-4">
                            <span className="font-medium text-white">{job.name}</span>
                          </td>
                          <td className="px-6 py-4">
                            <span className="text-sm text-slate-400 truncate max-w-xs block">{job.url}</span>
                          </td>
                          <td className="px-6 py-4">
                            <span className={`px-2 py-1 rounded text-xs font-medium ${getStatusColor(job.status)}`}>
                              {job.status}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <div className="w-32">
                              <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                                <span>{job.pagesScraped.toLocaleString()}</span>
                                <span>{job.progress}%</span>
                              </div>
                              <div className="w-full bg-slate-700 rounded-full h-1.5">
                                <div
                                  className={`h-1.5 rounded-full transition-all ${
                                    job.status === 'failed' ? 'bg-red-500' : 'bg-gradient-to-r from-cyan-500 to-blue-500'
                                  }`}
                                  style={{ width: `${job.progress}%` }}
                                />
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-4 text-xs text-slate-400">
                              <span className="flex items-center gap-1" title="Proxies Used">
                                <Shield className="w-3 h-3" /> {job.proxiesUsed}
                              </span>
                              <span className="flex items-center gap-1" title="CAPTCHAs Solved">
                                <CheckCircle className="w-3 h-3" /> {job.captchasSolved}
                              </span>
                              {job.errors > 0 && (
                                <span className="flex items-center gap-1 text-red-400" title="Errors">
                                  <AlertTriangle className="w-3 h-3" /> {job.errors}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center justify-end gap-2">
                              {job.status === 'running' && (
                                <button
                                  onClick={() => toggleJobStatus(job.id)}
                                  className="p-2 text-slate-400 hover:text-amber-400 hover:bg-slate-800 rounded-lg transition-colors"
                                >
                                  <Pause className="w-4 h-4" />
                                </button>
                              )}
                              {job.status === 'paused' && (
                                <button
                                  onClick={() => toggleJobStatus(job.id)}
                                  className="p-2 text-slate-400 hover:text-emerald-400 hover:bg-slate-800 rounded-lg transition-colors"
                                >
                                  <Play className="w-4 h-4" />
                                </button>
                              )}
                              <button
                                onClick={() => deleteJob(job.id)}
                                className="p-2 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-lg transition-colors"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {currentView === 'proxies' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <button className="px-4 py-2 bg-cyan-500 hover:bg-cyan-600 text-white rounded-lg font-medium transition-colors flex items-center gap-2">
                    <Plus className="w-4 h-4" />
                    Add Proxies
                  </button>
                  <button className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg font-medium transition-colors flex items-center gap-2">
                    <RefreshCw className="w-4 h-4" />
                    Rotate All
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-slate-400">Auto-rotation:</span>
                  <button className="relative w-12 h-6 bg-cyan-500 rounded-full transition-colors">
                    <span className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full transition-transform" />
                  </button>
                </div>
              </div>

              <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-slate-800/50">
                      <tr>
                        <th className="text-left px-6 py-4 text-sm font-medium text-slate-400">IP Address</th>
                        <th className="text-left px-6 py-4 text-sm font-medium text-slate-400">Port</th>
                        <th className="text-left px-6 py-4 text-sm font-medium text-slate-400">Location</th>
                        <th className="text-left px-6 py-4 text-sm font-medium text-slate-400">Status</th>
                        <th className="text-left px-6 py-4 text-sm font-medium text-slate-400">Success Rate</th>
                        <th className="text-left px-6 py-4 text-sm font-medium text-slate-400">Response</th>
                        <th className="text-left px-6 py-4 text-sm font-medium text-slate-400">Last Used</th>
                        <th className="text-right px-6 py-4 text-sm font-medium text-slate-400">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {proxyPool.map(proxy => (
                        <tr key={proxy.id} className="hover:bg-slate-800/30 transition-colors">
                          <td className="px-6 py-4">
                            <span className="font-mono text-white">{proxy.ip}</span>
                          </td>
                          <td className="px-6 py-4">
                            <span className="text-slate-300">{proxy.port}</span>
                          </td>
                          <td className="px-6 py-4">
                            <span className="text-slate-300">{proxy.country}</span>
                          </td>
                          <td className="px-6 py-4">
                            <span className={`px-2 py-1 rounded text-xs font-medium ${getStatusColor(proxy.status)}`}>
                              {proxy.status}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-2">
                              <div className="w-16 bg-slate-700 rounded-full h-1.5">
                                <div
                                  className={`h-1.5 rounded-full ${
                                    proxy.successRate >= 95 ? 'bg-emerald-500' :
                                    proxy.successRate >= 80 ? 'bg-amber-500' : 'bg-red-500'
                                  }`}
                                  style={{ width: `${proxy.successRate}%` }}
                                />
                              </div>
                              <span className={`text-sm ${proxy.successRate >= 95 ? 'text-emerald-400' : proxy.successRate >= 80 ? 'text-amber-400' : 'text-red-400'}`}>
                                {proxy.successRate}%
                              </span>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <span className={`text-sm ${proxy.responseTime < 200 ? 'text-emerald-400' : proxy.responseTime < 500 ? 'text-amber-400' : 'text-red-400'}`}>
                              {proxy.responseTime}ms
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <span className="text-sm text-slate-400">{proxy.lastUsed}</span>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => rotateProxy(proxy.id)}
                                className="p-2 text-slate-400 hover:text-cyan-400 hover:bg-slate-800 rounded-lg transition-colors"
                              >
                                <RefreshCw className="w-4 h-4" />
                              </button>
                              <button className="p-2 text-slate-400 hover:text-slate-300 hover:bg-slate-800 rounded-lg transition-colors">
                                <Eye className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => removeProxy(proxy.id)}
                                className="p-2 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-lg transition-colors"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {currentView === 'results' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <input
                    type="text"
                    placeholder="Search extracted data..."
                    className="px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                  />
                  <select className="px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-300 focus:outline-none focus:border-cyan-500">
                    <option>All Jobs</option>
                    <option>E-commerce Price Monitor</option>
                    <option>News Aggregator</option>
                  </select>
                </div>
                <button className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg font-medium transition-colors flex items-center gap-2">
                  Export CSV
                </button>
              </div>

              <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-slate-800/50">
                      <tr>
                        <th className="text-left px-6 py-4 text-sm font-medium text-slate-400">Job</th>
                        <th className="text-left px-6 py-4 text-sm font-medium text-slate-400">URL</th>
                        <th className="text-left px-6 py-4 text-sm font-medium text-slate-400">Extracted Data</th>
                        <th className="text-left px-6 py-4 text-sm font-medium text-slate-400">Status</th>
                        <th className="text-left px-6 py-4 text-sm font-medium text-slate-400">Timestamp</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {results.map(result => (
                        <tr key={result.id} className="hover:bg-slate-800/30 transition-colors">
                          <td className="px-6 py-4">
                            <span className="font-medium text-white">{result.jobName}</span>
                          </td>
                          <td className="px-6 py-4">
                            <span className="text-sm text-slate-400 truncate max-w-xs block">{result.url}</span>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex flex-wrap gap-2">
                              {Object.entries(result.data).slice(0, 4).map(([key, value]) => (
                                <span key={key} className="px-2 py-1 bg-slate-800 rounded text-xs text-slate-300">
                                  <span className="text-slate-500">{key}:</span> {value}
                                </span>
                              ))}
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <span className={`px-2 py-1 rounded text-xs font-medium ${getStatusColor(result.status)}`}>
                              {result.status}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <span className="text-sm text-slate-400">{new Date(result.scrapedAt).toLocaleString()}</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {currentView === 'settings' && (
            <div className="space-y-6 max-w-3xl">
              {/* CAPTCHA Settings */}
              <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <Shield className="w-5 h-5 text-cyan-400" />
                  CAPTCHA Solving Service
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Service Provider</label>
                    <select className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-slate-300 focus:outline-none focus:border-cyan-500">
                      <option>2Captcha</option>
                      <option>Anti-Captcha</option>
                      <option>CaptchaSolver</option>
                      <option>DeathByCaptcha</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">API Key</label>
                    <input
                      type="password"
                      placeholder="Enter your API key..."
                      className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                  <div className="flex items-center justify-between pt-2">
                    <span className="text-sm text-slate-400">Auto-solve CAPTCHAs</span>
                    <button className="relative w-12 h-6 bg-cyan-500 rounded-full transition-colors">
                      <span className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full transition-transform" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Retry Strategy */}
              <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <RefreshCw className="w-5 h-5 text-cyan-400" />
                  Retry Strategy
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Max Retry Attempts</label>
                    <input
                      type="number"
                      defaultValue={3}
                      className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Retry Delay (ms)</label>
                    <input
                      type="number"
                      defaultValue={1000}
                      className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                  <div className="flex items-center justify-between pt-2">
                    <span className="text-sm text-slate-400">Rotate proxy on failure</span>
                    <button className="relative w-12 h-6 bg-cyan-500 rounded-full transition-colors">
                      <span className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full transition-transform" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Request Settings */}
              <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <Globe className="w-5 h-5 text-cyan-400" />
                  Request Configuration
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Request Timeout (seconds)</label>
                    <input
                      type="number"
                      defaultValue={30}
                      className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Concurrent Requests</label>
                    <input
                      type="number"
                      defaultValue={10}
                      className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">User Agent Rotation</label>
                    <select className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-slate-300 focus:outline-none focus:border-cyan-500">
                      <option>Random Browser</option>
                      <option>Chrome Only</option>
                      <option>Firefox Only</option>
                      <option>Custom</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Save Button */}
              <button className="w-full px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white rounded-lg font-medium transition-all">
                Save Settings
              </button>
            </div>
          )}
        </div>
      </main>

      {/* New Job Modal */}
      {showNewJobModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-slate-900 rounded-2xl border border-slate-800 w-full max-w-2xl max-h-[90vh] overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
              <h3 className="text-lg font-semibold text-white">Create New Scrape Job</h3>
              <button
                onClick={() => setShowNewJobModal(false)}
                className="text-slate-400 hover:text-white transition-colors"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-4 overflow-y-auto max-h-[calc(90vh-140px)]">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Job Name</label>
                <input
                  type="text"
                  placeholder="Enter job name..."
                  className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Target URLs (one per line)</label>
                <textarea
                  placeholder="https://example.com/page1&#10;https://example.com/page2"
                  rows={4}
                  className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 resize-none"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Request Delay (ms)</label>
                  <input
                    type="number"
                    defaultValue={500}
                    className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Max Pages</label>
                  <input
                    type="number"
                    defaultValue={100}
                    className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Data Extraction Pattern</label>
                <select className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-slate-300 focus:outline-none focus:border-cyan-500">
                  <option>CSS Selectors</option>
                  <option>XPath</option>
                  <option>JSON Path</option>
                  <option>Regex</option>
                </select>
              </div>
              <div className="flex items-center gap-4 pt-4">
                <div className="flex items-center gap-2">
                  <input type="checkbox" id="useProxies" defaultChecked className="w-4 h-4 rounded border-slate-600 bg-slate-800 text-cyan-500 focus:ring-cyan-500" />
                  <label htmlFor="useProxies" className="text-sm text-slate-300">Use Proxy Rotation</label>
                </div>
                <div className="flex items-center gap-2">
                  <input type="checkbox" id="solveCaptchas" defaultChecked className="w-4 h-4 rounded border-slate-600 bg-slate-800 text-cyan-500 focus:ring-cyan-500" />
                  <label htmlFor="solveCaptchas" className="text-sm text-slate-300">Auto-solve CAPTCHAs</label>
                </div>
                <div className="flex items-center gap-2">
                  <input type="checkbox" id="followLinks" defaultChecked className="w-4 h-4 rounded border-slate-600 bg-slate-800 text-cyan-500 focus:ring-cyan-500" />
                  <label htmlFor="followLinks" className="text-sm text-slate-300">Follow Pagination</label>
                </div>
              </div>
            </div>
            <div className="px-6 py-4 border-t border-slate-800 flex items-center justify-end gap-3">
              <button
                onClick={() => setShowNewJobModal(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg font-medium transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => setShowNewJobModal(false)}
                className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white rounded-lg font-medium transition-all flex items-center gap-2"
              >
                <Play className="w-4 h-4" />
                Start Scraping
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
